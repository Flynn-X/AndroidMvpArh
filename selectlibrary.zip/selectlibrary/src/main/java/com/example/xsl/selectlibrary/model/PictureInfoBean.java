package com.example.xsl.selectlibrary.model;

/**
 * @author xsl
 * @version 1.0
 * @date 2017/4/17
 * @description
 */
public class PictureInfoBean {

    //图片名称
    public String name;
    //图片数据
    public byte[] data;
    //图片详情描述
    public String desc;
   //路径
    public String path;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public  byte[] getData() {
        return data;
    }

    public void setData( byte[] data) {
        this.data = data;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}