package com.example.xsl.selectlibrary.aty;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.xsl.selectlibrary.R;
import com.example.xsl.selectlibrary.adapter.CelerySelectPictureAdapter;
import com.example.xsl.selectlibrary.model.PictureInfoBean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CelerySelectPictureActivity extends AppCompatActivity {


    private Toolbar toolbar;
    private GridView gridView;
    private TextView confirm,title;
    private List<PictureInfoBean> list = new ArrayList<>();
    private CelerySelectPictureAdapter adapter;

    private String exTittle,exConfirmText,exConfirmTextColor,exCheckboxColor;
    private int resId;
    //选择图片默认是1张
    private int limit = 9;
    private List<String> seletedList = new ArrayList<>();
    HashMap<String,Boolean> hashMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_celery_select_picture);
        resId = getIntent().getIntExtra("exResId",-1);
        exTittle = getIntent().getStringExtra("exTittle");
        exConfirmText = getIntent().getStringExtra("exConfirmText");
        exConfirmTextColor = getIntent().getStringExtra("exConfirmTextColor");
        exCheckboxColor = getIntent().getStringExtra("exCheckboxColor");
        limit = getIntent().getIntExtra("limit",9);
        seletedList = (List<String>) getIntent().getSerializableExtra("data");
        init();
    }



    /**
     * 初始化
     */
    private void init() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("");
        toolbar.setTitleTextColor(0xffffffff);
        if (resId>0) {
            toolbar.setNavigationIcon(resId);
        }else {
            toolbar.setNavigationIcon(R.mipmap.celery_left);
        }
        setSupportActionBar(toolbar);
        title = (TextView) findViewById(R.id.title);
        confirm = (TextView) findViewById(R.id.confirm);
        gridView = (GridView) findViewById(R.id.gridView);
        for (int i=0;i<seletedList.size();i++){
            hashMap.put(seletedList.get(i),true);
        }
        adapter = new CelerySelectPictureAdapter(this, list, exCheckboxColor,limit,confirm,hashMap);
        gridView.setAdapter(adapter);

        if (!TextUtils.isEmpty(exTittle)){
            title.setText(exTittle);
        }

        if (!TextUtils.isEmpty(exTittle)){
            title.setText(exTittle);
        }

        if (!TextUtils.isEmpty(exConfirmText)){
            confirm.setText(exConfirmText);
        }

        if (!TextUtils.isEmpty(exConfirmTextColor)){
            confirm.setTextColor(Color.parseColor(exConfirmTextColor));
        }

        confirm.setOnClickListener(onClickListener);
        getdata();
    }

    /**
     * d单击事件
     */
    private View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            int i = v.getId();
             if (i == R.id.confirm) {
                Intent intent = new Intent();
                intent.putExtra("data", (Serializable) adapter.getdata());
                setResult(RESULT_OK,intent);
                finish();
            } else {
            }
        }
    };


    private void getdata() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");
                while (cursor.moveToNext()) {
                    PictureInfoBean pictureInfoBean = new PictureInfoBean();
                    //获取图片的名称
                    String name = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME));
                    //获取图片的生成日期
                    byte[] data = cursor.getBlob(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
                    //获取图片的详细信息
                    String desc = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DESCRIPTION));
                    pictureInfoBean.name = name;
                    pictureInfoBean.data = data;
                    pictureInfoBean.desc = desc;
                    pictureInfoBean.path = new String(data, 0, data.length - 1);
//                    Log.e("查询出的图片地址：", pictureInfoBean.path);
                    list.add(pictureInfoBean);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                    }
                });
            }
        }).start();

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
