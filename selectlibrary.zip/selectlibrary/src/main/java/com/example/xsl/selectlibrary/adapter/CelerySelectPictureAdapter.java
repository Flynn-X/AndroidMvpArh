package com.example.xsl.selectlibrary.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.xsl.selectlibrary.R;
import com.example.xsl.selectlibrary.model.PictureInfoBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author xsl
 * @version 1.0
 * @date 2017/4/17
 * @description
 */
public class CelerySelectPictureAdapter extends BaseAdapter {

    private Context context;
    private List<PictureInfoBean> list;
    private String colorStr;
    private int limit;
    private TextView cofirm;
    private HashMap<String,Boolean> hashMap = new HashMap<>();
    public CelerySelectPictureAdapter(Context context, List<PictureInfoBean> list,String colorStr,int limit,TextView cofirm,HashMap<String,Boolean> hashMap){
        this.context = context;
        this.list = list;
        this.colorStr = colorStr;
        this.limit = limit;
        this.cofirm = cofirm;
        this.hashMap = hashMap;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public List<String> getdata(){
        List<String> list = new ArrayList<>();
        Iterator it = hashMap.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (java.util.Map.Entry)it.next();
            list.add(entry.getKey()+"");
        }
        return list;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null){
            holder  = new ViewHolder();
            convertView = LayoutInflater.from(context).inflate(R.layout.activity_celery_select_picture_item,parent,false);
            holder.imageView = (ImageView) convertView.findViewById(R.id.imageView);
            holder.checkBox = (CheckBox) convertView.findViewById(R.id.checkBox);
            holder.mengcheng = (View) convertView.findViewById(R.id.mengcheng);
            convertView.setTag(holder);
        }else {
            holder = (ViewHolder) convertView.getTag();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && !TextUtils.isEmpty(colorStr)) {
            holder.checkBox.setButtonTintList(ColorStateList.valueOf(Color.parseColor(colorStr)));
        }

        Glide.with(context)
                .load(list.get(position).getPath())
                .placeholder(R.drawable.celery_picture_default)
                .crossFade()
                .into(holder.imageView);

        final ViewHolder finalHolder = holder;
        holder.checkBox.setTag(list.get(position).getPath());
        holder.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked && (hashMap.containsKey(list.get(position).getPath()) || hashMap.size()<limit)) {
                    finalHolder.mengcheng.setVisibility(View.VISIBLE);
                    if (!hashMap.containsKey(list.get(position).getPath())) {
                        hashMap.put(list.get(position).getPath(), true);
                        cofirm.setText("确定(" + hashMap.size() + "/" + limit + ")");
                    }
                } else {
                    finalHolder.mengcheng.setVisibility(View.INVISIBLE);
                    finalHolder.checkBox.setChecked(false);
                    if (hashMap.containsKey(list.get(position).getPath())) {
                        hashMap.remove(list.get(position).getPath());
                        if (hashMap.size()==0){
                            cofirm.setText("确定");
                        }
                      }
                    }
                    if (isChecked && !hashMap.containsKey(list.get(position).getPath()) && hashMap.size()>=limit){
                        Toast.makeText(context, "最多只可以选 " + limit + " 张图片", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        if (hashMap.containsKey(list.get(position).getPath())){
            holder.checkBox.setChecked(true);
            holder.mengcheng.setVisibility(View.VISIBLE);
        }else {
            holder.checkBox.setChecked(false);
            holder.mengcheng.setVisibility(View.INVISIBLE);
        }

        return convertView;
    }

    private static class ViewHolder{
        ImageView imageView;
        View mengcheng;
        CheckBox checkBox;
    }



}